Import the folder in Eclipse and run the files under src
To run from command line
cd till src(cd/src)
java Main.java