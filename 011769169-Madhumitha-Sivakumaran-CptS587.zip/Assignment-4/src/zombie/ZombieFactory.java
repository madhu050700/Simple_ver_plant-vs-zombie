package zombie;

import creation_zombie.Zombie;

public abstract class ZombieFactory {
	
	public abstract Zombie createZombies();


}
