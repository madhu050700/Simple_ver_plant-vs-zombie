package creation_zombie;


public class ScreenZombie extends OtherZombieGroup {


	
	
	public ScreenZombie() {
		this.health = 25;
		this.zombie = new RegularZombie();
	}

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		 return "S/" + this.getHealth();
	}
}
