package creation_zombie;

import java.util.ArrayList;
import java.util.List;


public abstract class OtherZombieGroup implements Zombie {
	
	protected int health;
	protected Zombie zombie;
	List<Zombie> zombie1 = new ArrayList<Zombie>();
	

	@Override
	public  Zombie takeDamage(int d) {
		health -= d;
		if (health <= 0) { 
			
				if(zombie ==null) {
					return null;
				}
				return zombie.takeDamage(0-health);
			}
        return this;	
	};
	@Override
	public void addZombie(Zombie z) {
		zombie1.add(z);
		
	}

	@Override
	public void removeZombie(Zombie z) {
		zombie1.remove(z);
		
	}

	@Override
	public  int getHealth() {
		if(zombie ==null) {
			return health;
		}
		return health + zombie.getHealth();
		
	};
		
	@Override
	public abstract String toString();


}
