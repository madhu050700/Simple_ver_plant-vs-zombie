package creation_zombie;

public class BucketZombie extends OtherZombieGroup{
	
	public BucketZombie() {
		this.health = 100;
		this.zombie = new RegularZombie();
	}
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		 return "B/" + this.getHealth();
	}
}
