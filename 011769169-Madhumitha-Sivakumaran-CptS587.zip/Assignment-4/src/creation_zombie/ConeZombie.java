package creation_zombie;



public class ConeZombie extends OtherZombieGroup{
		
	
	public ConeZombie() {
		this.health = 25;
		this.zombie = new RegularZombie();
	}
	
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		 return "C/" + this.getHealth();
	}


}
